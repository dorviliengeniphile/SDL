import { Button } from "@/components/ui/button";
import { Search, ShoppingBag, DollarSign } from "lucide-react";
import heroImage from "@/assets/hero-marketplace.jpg";

const Hero = () => {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-hero" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Achetez et vendez{" "}
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  tout ce que vous voulez
                </span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Rejoignez des millions d'utilisateurs sur la plateforme de marketplace 
                la plus moderne. Découvrez des produits uniques ou vendez les vôtres 
                en quelques clics.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="hero" size="hero" className="flex-1 sm:flex-none">
                <Search className="h-5 w-5 mr-2" />
                Explorer les produits
              </Button>
              <Button variant="accent" size="hero" className="flex-1 sm:flex-none">
                <DollarSign className="h-5 w-5 mr-2" />
                Commencer à vendre
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">10M+</div>
                <div className="text-sm text-muted-foreground">Produits</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">2M+</div>
                <div className="text-sm text-muted-foreground">Vendeurs</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">50M+</div>
                <div className="text-sm text-muted-foreground">Clients</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-elegant">
              <img
                src={heroImage}
                alt="Marketplace products"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
            </div>
            <div className="absolute -bottom-4 -right-4 bg-accent text-accent-foreground p-4 rounded-xl shadow-glow">
              <ShoppingBag className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;