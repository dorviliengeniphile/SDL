import { Smartphone, Laptop, Headphones, Shirt, Home, Book, Camera, Watch } from "lucide-react";
import { Button } from "@/components/ui/button";

const categories = [
  { name: "Électronique", icon: Smartphone, count: "12,543" },
  { name: "Ordinateurs", icon: Laptop, count: "8,721" },
  { name: "Audio", icon: Headphones, count: "5,432" },
  { name: "Mode", icon: Shirt, count: "15,678" },
  { name: "Maison", icon: Home, count: "9,876" },
  { name: "Livres", icon: Book, count: "23,456" },
  { name: "Photo", icon: Camera, count: "3,254" },
  { name: "Montres", icon: Watch, count: "2,134" },
];

const Categories = () => {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Explorez par catégorie</h2>
          <p className="text-muted-foreground text-lg">
            Découvrez des millions de produits dans toutes les catégories
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Button
                key={category.name}
                variant="ghost"
                className="h-auto p-6 flex flex-col items-center space-y-3 hover:bg-card hover:shadow-md transition-smooth border border-transparent hover:border-border"
              >
                <div className="p-3 bg-primary/10 rounded-full">
                  <IconComponent className="h-6 w-6 text-primary" />
                </div>
                <div className="text-center">
                  <div className="font-medium text-sm">{category.name}</div>
                  <div className="text-xs text-muted-foreground">{category.count} produits</div>
                </div>
              </Button>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Categories;